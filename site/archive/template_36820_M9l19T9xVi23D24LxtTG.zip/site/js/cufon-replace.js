Cufon.replace('ul.sf-menu li a, ul.sf-menu li>ul>li>a, ul.sf-menu>li>ul>li>a', { fontFamily: 'Century_gothic',textShadow:'rgba(233,224,229,.6) 1px 1px', hover:true});
Cufon.replace('.slider-text strong, .caption', { fontFamily: 'Century_gothic'});
Cufon.replace('h3, h4, h5, h2', { fontFamily: 'Yellowtail',color: '-linear-gradient(#f5f3f5, #ac95ad)'});
Cufon.replace('.page-2-banner-img div strong, .page-2-banner-text strong.col-1', { fontFamily: 'Century',color: '-linear-gradient(#f5f3f5, #ac95ad)'});
Cufon.replace('.page-2-banner-text strong.col-2', { fontFamily: 'Century',color: '-linear-gradient(#f5f3f5, #ff6ba2)'});